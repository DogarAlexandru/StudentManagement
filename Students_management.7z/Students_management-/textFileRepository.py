from domain import *
from repository import *
class studentListText(studentList):
    """
    The class represents a list of students
    Elements of the class:
    li - LIST of entities of the class STUDENT
    """
    def __init__(self,file):
        studentList.__init__(self)
        self.fi=file
        self.loadFromFile()

    def loadFromFile(self):
        try:
            f = open(self.fi, "r")
        except IOError:
            return
        cont=-1
        line=f.readline().strip()
        while line!="":
            t=line.split(";")
            st=student(t[1],int(t[0]))
            self.addStudent(st)
            cont=cont+1
            for i in range(2,len(t)-1):
                self.li[cont].addDiscipline(int(t[i]))
            line = f.readline().strip()
        f.close()

    def saveToFile(self):
        try:
            f = open(self.fi, "w")
        except IOError:
            return
        for i in range(len(self.li)):
            f.write(str(self.li[i].id) + ";" + self.li[i].name+";")
            for j in range(len(self.li[i].dl)):
                f.write(str(self.li[i].dl[j])+";")
            f.write("\n")
        f.close()

    def addStudent(self,st):
        """
        Adds a student to the student list
        Adds an enetity of the class STUDENT to the LIST  of STDUENT class entities li

        Input st - entity of class STUDENT
        """
        studentList.addStudent(self,st)
        self.saveToFile()

    def removeStudent(self,id):
        """
        Removes a student from the list of students
        Removes THE FIRST APPARITION of the enetity of class STUDENT from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the student you want removed
        """
        studentList.removeStudent(self,id)
        self.saveToFile()

class disciplineListText(disciplineList):
    """
    The class represents a list of disciplines
    Elements of the class:
    li - LIST of entities of the class DISCIPLNE
    """
    def __init__(self,file):
        disciplineList.__init__(self)
        self.fi=file
        self.loadFromFile()

    def saveToFile(self):
        try:
            f = open(self.fi, "w")
        except IOError:
            return
        for i in range(len(self.li)):
            f.write(str(self.li[i].id)+";"+self.li[i].name+"\n")
        f.close()

    def loadFromFile(self):
        try:
            f = open(self.fi, "r")
        except IOError:
            return
        cont=-1
        line=f.readline().strip()
        while line != "":
            t = line.split(";")
            di=discipline(t[1],int(t[0]))
            self.addDiscipline(di)
            cont = cont + 1
            line = f.readline().strip()
        f.close()

    def addDiscipline(self,di):
        """
        Adds a discipline to the discipline list
        Adds an entity of class DISCIPLINE to the LIST of entities of class DISCIPLINE li

        Input di - entity of class DISCIPLINE
        """
        disciplineList.addDiscipline(self,di)
        self.saveToFile()

    def removeDiscipline(self,id):
        """
        Removes a discipline from the discipline list
        Removes THE FIRST APPARITION of the enetity of class DISCIPLINE from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the disicpline you want removed
        """
        disciplineList.removeDiscipline(self,id)
        self.saveToFile()

class gradeListText(gradeList):
    """
    Represents the lsit of grades given at the school
    Contains 1 element:
    li - LIST of entities of class GRADE
    """
    def __init__(self,file):
        gradeList.__init__(self)
        self.fi=file
        self.loadFromFile()

    def saveToFile(self):
        try:
            f = open(self.fi, "w")
        except IOError:
            return
        for i in range(len(self.li)):
            f.write(str(self.li[i].did)+";"+str(self.li[i].sid)+";"+str(self.li[i].v)+"\n")
        f.close()

    def loadFromFile(self):
        try:
            f = open(self.fi, "r")
        except IOError:
            return
        cont=-1
        line=f.readline().strip()
        while line != "":
            t = line.split(";")
            gr=grade(int(t[1]),int(t[0]),int(t[2]))
            self.addGrade(gr)
            line = f.readline().strip()
        f.close()

    def addGrade(self,g):
        """
        Adds a grade to the grade list
        Adds an entity of the class GRADE to the LIST of entities of class GRADE

        Input g - entity of class GRADE
        """
        gradeList.addGrade(self,g)
        self.saveToFile()

    def removeGradeStd(self,id):
        """
        Removes the grades of the students with a given id from the grade list
        Removes ALL THE  APPARITIONS of the enetity of class GRADE from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the student who's grade you want removed
        """
        gradeList.removeGradeStd(self,id)
        self.saveToFile()

    def removeGradeDis(self,id):
        """
        Removes the grades of the discipline with a given id from the grade list
        Removes ALL THE  APPARITIONS of the enetity of class GRADE from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the discipline who's grade you want removed
        """
        gradeList.removeGradeDis(self,id)
        self.saveToFile()

    def removeLastGrade(self):
        """
        Removes the element last added to the LIST of entities of class GRADE
        """
        gradeList.removeLastGrade(self)
        self.saveToFile()