from domain import *
from repository import *
from controler import *
sList=studentList()
dList=disciplineList()
gangstaList=gradeList()
def testDomain():
    def testStudent():
        def testsInit():
            s1=student("alex",231)
            assert s1.name=="alex"
            assert s1.id==231
            assert s1.dl==[]
            s1.dl.append(23)
            assert s1.dl==[23]

            s2=student("","")
            assert s2.name==""
            assert s2.id==""
        def testChagesName():
            s1=student("alex",3)
            assert s1.name == "alex"
            s1.changeName("vio")
            assert s1.name == "vio"
            s1.changeName("")
            assert s1.name == ""
            s1.changeName(321)
            assert s1.name == 321
        def testChangesID():
            s1 = student("alex", 3)
            assert s1.id == 3
            s1.changeID(45)
            assert s1.id==45
            s1.changeID("")
            assert s1.id == ""
            s1.changeID("dsa")
            assert s1.id == "dsa"
        def testIsEnrolled():
            s1 = student("alex", 231)
            assert s1.dl == []
            assert s1.isEnrolled("mate")==False
            s1.dl.append("mate")
            assert s1.isEnrolled("mate") == True
            assert s1.dl == ["mate"]
            s1.dl.append("")
            assert s1.isEnrolled("") == True
            assert s1.dl == ["mate",""]
            assert s1.isEnrolled("istorie")==False
        def testAddDiscipline():
            s1 = student("alex", 3)
            assert s1.dl == []
            s1.addDiscipline("mate")
            assert s1.dl== ["mate"]
            s1.addDiscipline(32)
            assert s1.dl == ["mate",32]
            s1.addDiscipline("")
            assert s1.dl == ["mate",32,""]
            s1.addDiscipline("mate32")
            assert s1.dl == ["mate",32,"","mate32"]
            s1.addDiscipline("mate32")
            assert s1.dl == ["mate", 32, "", "mate32"]
        def testRemoveDiscipline():
            s1 = student("alex", 3)
            assert s1.dl == []
            s1.addDiscipline("mate")
            assert s1.dl == ["mate"]
            s1.addDiscipline(32)
            assert s1.dl == ["mate", 32]
            s1.addDiscipline("")
            assert s1.dl == ["mate", 32, ""]
            s1.addDiscipline("mate32")
            assert s1.dl == ["mate", 32, "", "mate32"]
            s1.addDiscipline("mate32")
            assert s1.dl == ["mate", 32, "", "mate32"]
            s1.removeDiscipline("mate")
            assert s1.dl==[32,"","mate32"]
            s1.removeDiscipline("")
            assert s1.dl == [32, "mate32"]
            s1.removeDiscipline(32)
            assert s1.dl == ["mate32"]
            s1.removeDiscipline("mate32")
            assert s1.dl == []

        testsInit()
        testAddDiscipline()
        testChagesName()
        testChangesID()
        testIsEnrolled()
        testRemoveDiscipline()
    def testDiscipline():
        def testdInit():
            d1=discipline("mate",32)
            assert d1.name=="mate"
            assert d1.id==32
            d2 = discipline("", 32)
            assert d2.name == ""
            assert d2.id == 32
            d3 = discipline("mate", "")
            assert d3.name == "mate"
            assert d3.id == ""
        def testChangedID():
            d1 = discipline("mate", 32)
            assert d1.name == "mate"
            assert d1.id == 32
            d2 = discipline("", 32)
            assert d2.name == ""
            assert d2.id == 32
            d3 = discipline("mate", "")
            assert d3.name == "mate"
            assert d3.id == ""
            d1.changeID(34)
            assert d1.id==34
            d2.changeID(0)
            assert d2.id==0
        def testChangedName():
            d1 = discipline("mate", 32)
            assert d1.name == "mate"
            assert d1.id == 32
            d2 = discipline("", 32)
            assert d2.name == ""
            assert d2.id == 32
            d3 = discipline("mate", "")
            assert d3.name == "mate"
            assert d3.id == ""
            d1.changeName("istorie")
            assert d1.name=="istorie"
            d3.changeName("")
            assert d3.name == ""

        testdInit()
        testChangedID()
        testChangedName()
    def testGrade():
        def testgInit():
            g=grade(23,32,5)
            assert g.sid==23
            assert g.did==32
            assert g.v==5

        testgInit()

    testStudent()
    testDiscipline()
    testGrade()

def testRepository():
    def testStudentList():
        def testsInit():
            l=studentList()
            assert l.li==[]
            s=student("alex",34)
            l.li.append(s)
            assert l.li[0].name=="alex"
            assert l.li[0].id == 34
        def testAddStudent():
            l = studentList()
            assert l.li == []
            s1 = student("alex", 34)
            l.li.append(s1)
            assert l.li[0].name == "alex"
            s2 = student("tudor", 42)
            l.addStudent(s2)
            assert l.li[1].id == 42
            assert l.li[1].name == "tudor"
            s3= student("olaf",3221)
            l.addStudent(s3)
            assert l.li[1].name == "tudor"
            assert l.li[2].name == "olaf"
            assert l.li[2].id == 3221
        def testRemoveStudent():
            l = studentList()
            assert l.li == []
            s1 = student("alex", 34)
            l.li.append(s1)
            assert l.li[0].name == "alex"
            s2 = student("tudor", 42)
            l.addStudent(s2)
            assert l.li[1].id == 42
            assert l.li[1].name == "tudor"
            s3 = student("olaf", 3221)
            l.addStudent(s3)
            assert l.li[1].name == "tudor"
            assert l.li[2].name == "olaf"
            assert l.li[2].id == 3221
            l.removeStudent(42)
            assert l.li[1].name == "olaf"
            assert l.li[1].id == 3221
            assert l.li[0].name == "alex"
            assert len(l.li)==2
            l.removeStudent(34)
            l.removeStudent(3221)
            assert len(l.li)==0
        def testIsIDinsList():
            l = studentList()
            assert l.li == []
            s1 = student("alex", 34)
            l.li.append(s1)
            assert l.li[0].name == "alex"
            s2 = student("tudor", 42)
            l.addStudent(s2)
            assert l.li[1].id == 42
            assert l.li[1].name == "tudor"
            s3 = student("olaf", 3221)
            l.addStudent(s3)
            assert l.li[1].name == "tudor"
            assert l.li[2].name == "olaf"
            assert l.li[2].id == 3221
            assert l.isIDinList(3221)==True
            assert l.isIDinList(311)==False
            assert l.isIDinList("das")==False

        testsInit()
        testAddStudent()
        testRemoveStudent()
        testIsIDinsList()
    def testDisciplineList():
        def testdInit():
            l = disciplineList()
            assert l.li == []
            d = discipline("mate", 32)
            l.li.append(d)
            assert l.li[0].name == "mate"
            assert l.li[0].id == 32
        def testAddDiscipline():
            l = disciplineList()
            assert l.li == []
            d1 = discipline("mate", 32)
            l.li.append(d1)
            assert l.li[0].name == "mate"
            assert l.li[0].id == 32
            d2= discipline("dsa",45)
            l.addDiscipline(d2)
            assert len(l.li)==2
            assert l.li[1].name=="dsa"
            assert l.li[1].id==45
        def testRemoveDiscipline():
            l = disciplineList()
            assert l.li == []
            d1 = discipline("mate", 32)
            l.li.append(d1)
            assert l.li[0].name == "mate"
            assert l.li[0].id == 32
            d2 = discipline("dsa", 45)
            l.addDiscipline(d2)
            assert len(l.li) == 2
            assert l.li[1].name == "dsa"
            assert l.li[1].id == 45
            l.removeDiscipline(32)
            assert len(l.li) == 1
            assert l.li[0].name == "dsa"
            assert l.li[0].id == 45
            l.removeDiscipline(45)
            assert len(l.li) == 0
        def testIsIDindList():
            l = disciplineList()
            assert l.isIDinList(32)==False
            assert l.li == []
            d1 = discipline("mate", 32)
            l.li.append(d1)
            assert l.isIDinList(32) == True
            assert l.li[0].name == "mate"
            assert l.li[0].id == 32
            d2 = discipline("dsa", 45)
            assert l.isIDinList(45) == False
            l.addDiscipline(d2)
            assert len(l.li) == 2
            assert l.li[1].name == "dsa"
            assert l.li[1].id == 45
            assert l.isIDinList(45) ==True
            l.removeDiscipline(32)
            assert l.isIDinList(32) == False
            assert len(l.li) == 1
            assert l.li[0].name == "dsa"
            assert l.li[0].id == 45
            l.removeDiscipline(45)
            assert l.isIDinList(45) == False
            assert len(l.li) == 0

        testdInit()
        testAddDiscipline()
        testRemoveDiscipline()
        testIsIDindList()
    def testGradeList():
        def testAddGrade():
            l=gradeList()
            assert len(l.li)==0
            g=grade(1,3,5)
            l.addGrade(g)
            assert len(l.li) == 1
            assert l.li[0].sid==1
            assert l.li[0].did == 3
            assert l.li[0].v == 5
        def testRemoveGradeStd():
            l = gradeList()
            assert len(l.li) == 0
            g = grade(3, 1, 5)
            l.addGrade(g)
            assert len(l.li) == 1
            assert l.li[0].sid == 3
            assert l.li[0].did == 1
            assert l.li[0].v == 5
            g = grade(3, 2, 7)
            l.addGrade(g)
            assert len(l.li) == 2
            assert l.li[1].sid == 3
            assert l.li[1].did == 2
            assert l.li[1].v == 7
            g = grade(4, 1, 6)
            l.addGrade(g)
            assert len(l.li) == 3
            assert l.li[2].sid == 4
            assert l.li[2].did == 1
            assert l.li[2].v == 6
            l.removeGradeStd(3)
            assert len(l.li) == 1
            assert l.li[0].sid == 4
            assert l.li[0].did == 1
            assert l.li[0].v == 6
            l.removeGradeStd(4)
            assert len(l.li) == 0
        def testRemoveGradeDis():
            l = gradeList()
            assert len(l.li) == 0
            g = grade(3, 1, 5)
            l.addGrade(g)
            assert len(l.li) == 1
            assert l.li[0].sid == 3
            assert l.li[0].did == 1
            assert l.li[0].v == 5
            g = grade(2, 3, 7)
            l.addGrade(g)
            assert len(l.li) == 2
            assert l.li[1].sid == 2
            assert l.li[1].did == 3
            assert l.li[1].v == 7
            g = grade(4, 1, 6)
            l.addGrade(g)
            assert len(l.li) == 3
            assert l.li[2].sid == 4
            assert l.li[2].did == 1
            assert l.li[2].v == 6
            l.removeGradeDis(1)
            assert len(l.li) == 1
            assert l.li[0].sid == 2
            assert l.li[0].did == 3
            assert l.li[0].v == 7
            l.removeGradeDis(3)
            assert len(l.li) == 0

        testAddGrade()
        testRemoveGradeDis()
        testRemoveGradeStd()

    testDisciplineList()
    testStudentList()
    testGradeList()

def testControler():
    def testAddStudent():
        c=controler(sList,dList,gangstaList)
        c.addStudent("alex",1)
        assert len(c.s.li)==1
        assert c.s.li[0].name=="alex"
        assert c.s.li[0].id == 1
        c.addStudent("ads", 2)
        assert len(c.s.li) == 2
        assert c.s.li[1].name == "ads"
        assert c.s.li[1].id == 2
        c.addStudent("tete", 3)
        assert len(c.s.li) == 3
        assert c.s.li[2].name == "tete"
        assert c.s.li[2].id == 3
    def testRemoveStudent():
        c = controler(sList, dList, gangstaList)
        c.addDiscipline("mate", 7)
        c.addDiscipline("info", 8)
        c.addDiscipline("istorie", 9)
        c.enrollStudent(1,7)
        c.enrollStudent(1,7)
        c.enrollStudent(1,8)
        c.enrollStudent(2,7)
        c.addGrade(1, 7, 7)
        c.addGrade(2, 7, 8)
        c.addGrade(1, 8, 5)
        c.removeStudent(6)
        assert len(c.s.li)==3
        assert c.s.li[0].name=="alex"
        assert c.s.li[0].id== 1
        assert len(c.g.li)==3
        c.removeStudent(1)
        assert len(c.s.li)==2
        assert c.s.li[0].name=="ads"
        assert c.s.li[0].id== 2
        assert len(c.g.li)==1
        assert c.g.li[0].sid==2
        assert c.g.li[0].did==7
        assert c.g.li[0].v==8
        c.removeStudent(2)
        assert len(c.s.li)==1
        assert c.s.li[0].name=="tete"
        assert c.s.li[0].id== 3
        assert len(c.g.li)==0
        c.removeStudent(3)
        assert len(c.s.li)==0
    def testremoveDiscipline():
        c = controler(sList, dList, gangstaList)
        c.addStudent("alex", 1)
        c.addStudent("ads", 2)
        c.addStudent("tete", 3)
        c.enrollStudent(1,7)
        c.enrollStudent(1,7)
        c.enrollStudent(1,8)
        c.enrollStudent(2,7)
        c.addGrade(1, 7, 7)
        c.addGrade(2, 7, 8)
        c.addGrade(1,8,5)
        c.removeDiscipline(7)
        assert len(c.d.li)==2
        assert c.d.li[0].name=="info"
        assert c.d.li[0].id==8
        assert len(c.g.li)==1
        assert c.g.li[0].sid==1
        assert c.g.li[0].did ==8
        c.removeDiscipline(8)
        assert len(c.d.li)==1
        assert c.d.li[0].name=="istorie"
        assert c.d.li[0].id==9
        assert len(c.g.li)==0
        c.removeDiscipline(9)
        assert len(c.d.li)==0
    def testAddDiscipline():
        c = controler(sList, dList, gangstaList)
        c.addDiscipline("mate",7)
        assert len(c.d.li)==1
        assert c.d.li[0].name=="mate"
        assert c.d.li[0].id == 7
        c.addDiscipline("info",8)
        assert len(c.d.li)==2
        assert c.d.li[1].name=="info"
        assert c.d.li[1].id == 8
        c.addDiscipline("istorie",9)
        assert len(c.d.li)==3
        assert c.d.li[2].name=="istorie"
        assert c.d.li[2].id == 9
    def testAddGrade():
        c = controler(sList, dList, gangstaList)
        c.addGrade(1,7,7)
        assert len(c.g.li)==1
        assert c.g.li[0].sid==1
        assert c.g.li[0].did==7
        assert c.g.li[0].v==7
        c.addGrade(2,7,8)
        assert len(c.g.li)==2
        assert c.g.li[1].sid==2
        assert c.g.li[1].did==7
        assert c.g.li[1].v==8
        c.addGrade(1,255,7)
        assert len(c.g.li)==2
        assert c.g.li[0].sid==1
        assert c.g.li[0].did==7
        assert c.g.li[0].v==7
        c.addGrade(455,7,7)
        assert len(c.g.li)==2
        assert c.g.li[1].sid==2
        assert c.g.li[1].did==7
        assert c.g.li[1].v==8
    def testEnrollStudent():
        c = controler(sList, dList, gangstaList)
        c.enrollStudent(1,7)
        assert len(c.s.li[0].dl)==2
        assert c.s.li[0].dl[0]==7
        c.enrollStudent(250,7)
        assert len(c.s.li[0].dl)==2
        assert c.s.li[0].dl[0]==7
        c.enrollStudent(1,240)
        assert len(c.s.li[0].dl)==2
        assert c.s.li[0].dl[0]==7
        c.enrollStudent(1,7)
        assert len(c.s.li[0].dl)==2
        assert c.s.li[0].dl[0]==7

        c.enrollStudent(1,8)
        assert len(c.s.li[0].dl)==2
        assert c.s.li[0].dl[1]==8
        c.enrollStudent(2,7)
        assert len(c.s.li[1].dl)==1
        assert c.s.li[1].dl[0]==7
        c.enrollStudent(1,7)
        assert len(c.s.li[0].dl)==2
        assert c.s.li[0].dl[0]==7
        c.enrollStudent(1,7)
        assert len(c.s.li[0].dl)==2
        assert c.s.li[0].dl[1]==8
    def testRemoveStudentFromDiscipline():
        c = controler(sList, dList, gangstaList)
        assert c.s.li[0].dl[0] == 7
        assert c.s.li[0].dl[1] == 8
        assert c.s.li[1].dl[0] == 7
        c.removeStudentFromDiscipline(1,10)
        assert len(c.s.li[0].dl)==2
        assert c.s.li[0].dl[0]==7
        c.removeStudentFromDiscipline(1,9)
        assert len(c.s.li[0].dl)==2
        assert c.s.li[0].dl[0]==7
        c.removeStudentFromDiscipline(1,7)
        assert len(c.s.li[0].dl)==1
        assert c.s.li[0].dl[0]==8
        c.removeStudentFromDiscipline(1,7)
        assert len(c.s.li[0].dl)==1
        assert c.s.li[0].dl[0]==8
        c.removeStudentFromDiscipline(1,8)
        assert len(c.s.li[0].dl)==0
        c.removeStudentFromDiscipline(2,7)
        assert len(c.s.li[1].dl)==0
    def testChangeStudentName():
        c = controler(sList, dList, gangstaList)
        c.enrollStudent(1,7)
        c.enrollStudent(1,8)
        c.enrollStudent(2,7)
        c.changeStudentName(1,"roby")
        assert c.s.li[0].name=="roby"
        c.changeStudentName(2, "roby")
        assert c.s.li[1].name == "roby"
        c.changeStudentName(3, "roby")
        assert c.s.li[2].name == "roby"
    def testChangeStudentID():
        c = controler(sList, dList, gangstaList)
        c.enrollStudent(2,8)
        c.addGrade(2,8,6)
        c.changeStudentID(1,4)
        assert len(c.s.li)==3
        assert c.s.li[0].id==4
        assert c.s.li[0].name == "roby"
        assert c.g.li[0].sid==4
        c.changeStudentID(4, 1)
        assert len(c.s.li) == 3
        assert c.s.li[0].id == 1
        assert c.s.li[0].name == "roby"
        assert c.g.li[0].sid == 1
        c.changeStudentID(6, 4)
        assert len(c.s.li) == 3
        c.changeStudentID(1, 3)
        assert len(c.s.li) == 3
        assert c.s.li[0].id == 1
        assert c.s.li[0].name == "roby"
        assert c.g.li[0].sid == 1
        c.changeStudentID(2, 4)
        assert len(c.s.li) == 3
        assert c.s.li[1].id == 4
        assert c.s.li[0].name == "roby"
        assert c.g.li[1].sid == 4
        assert c.g.li[2].sid == 4
        c.changeStudentID(4, 2)
        assert len(c.s.li) == 3
        assert c.s.li[1].id == 2
        assert c.s.li[0].name == "roby"
        assert c.g.li[1].sid == 2
        assert c.g.li[2].sid == 2
    def testChangeDisciplineName():
        c = controler(sList, dList, gangstaList)
        c.changeDisciplineName(8,"bio")
        assert len(c.d.li)==3
        assert c.d.li[1].name=="bio"
        assert c.d.li[1].id == 8
        c.changeDisciplineName(9, "bio")
        assert len(c.d.li) == 3
        assert c.d.li[2].name == "bio"
        assert c.d.li[2].id == 9
        c.changeDisciplineName(7, "bio")
        assert len(c.d.li) == 3
        assert c.d.li[0].name == "bio"
        assert c.d.li[0].id == 7
    def testChageDisciplineID():
        c = controler(sList, dList, gangstaList)
        c.changeDisciplineID(8, 9)
        assert len(c.d.li) == 3
        assert c.d.li[1].name == "bio"
        assert c.d.li[1].id == 8
        assert c.g.li[2].did == 8
        c.changeDisciplineID(8, 10)
        assert len(c.d.li) == 3
        assert c.d.li[1].name == "bio"
        assert c.d.li[1].id == 10
        assert c.g.li[2].did == 10
        c.changeDisciplineID(10, 8)
        assert len(c.d.li) == 3
        assert c.d.li[1].name == "bio"
        assert c.d.li[1].id == 8
        assert c.g.li[2].did == 8
        c.changeDisciplineID(7, 10)
        assert len(c.d.li) == 3
        assert c.d.li[0].name == "bio"
        assert c.d.li[0].id == 10
        assert c.g.li[0].did == 10
        assert c.g.li[1].did == 10
        c.changeDisciplineID(10, 7)
        assert len(c.d.li) == 3
        assert c.d.li[0].name == "bio"
        assert c.d.li[0].id == 7
        assert c.g.li[0].did == 7
        assert c.g.li[1].did == 7


    testAddStudent()
    testRemoveStudent()
    testremoveDiscipline()
    testAddDiscipline()
    testAddGrade()
    testEnrollStudent()
    testRemoveStudentFromDiscipline()
    testChangeStudentName()
    testChangeStudentID()
    testChangeDisciplineName()

def runTests():
    testDomain()
    testRepository()
    testControler()