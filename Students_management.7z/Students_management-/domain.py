class student():
    """
    The class student contains 3 elements:
    name - a STRING representing the name of a student
    id - a POSITIVE INTEGER representing the id of a student
    dl - a LIST of POSITIVE INTEGERS representing the id's of the  disciplines a student is enroled in
    """
    def __init__(self,n,id):
        self.name=n
        self.id=id
        self.dl=[]
    def changeName(self,new):
        """
        Modifies the value of the NAME element of SELF
        Input new - STRING representing the new name that the student will have
        """
        self.name=new

    def changeID(self,new):
        """
        Modifies the value of the ID element of SELF
        Input new - POSITIVE INTEGER representing the new id that the student will have
        """
        self.id=new

    def isEnrolled(self,dis):
        """
        Verifies if the POSITIVE INTEGER dis is a part of the LIST of POSITIVE INTEGERS dl , returning TRUE if it is a part
        of the list and FALSE if it isn't a part of the list.
        This verifies if a student is enrolled at the discipline given trough DIS

        Input dis - POSITIVE INTEGER representing given discipline ID
        Output TRUE or FALSE by case
        """
        for i in range(len(self.dl)):
            if self.dl[i]==dis:
                return True
        return False

    def addDiscipline(self,dis):
        """
        Adds a discipline ID  to the list of discipline id's a student is enrolled in, if the student wasn't already
        enrolled at that discipline
        Adds a POSITIVE INTEGER(given trough dis) to the LIST of POSITIVE INTEGERS dl , if the list didnt already contain that
        integer

        Input dis - POSITIVE INTEGER representing given discipline ID
        """
        if self.isEnrolled(dis)==False:
            self.dl.append(dis)

    def removeDiscipline(self,dis):
        """
        Removes a discipline id from the list of discipline id's a student is enrolled in, but only if the student
        is already enrolled at that discipline
        Removes  the FIRST ITTERATION of a POSITIVE INTEGER(given trough dis) from the LIST of POSITIVE INTEGERS dl ,
        if the list contains that string

        Input dis - POSITIVE INTEGER representing given discipline ID
        """
        if self.isEnrolled(dis)==True:
            for i in range(len(self.dl)):
                if self.dl[i] == dis:
                    self.dl.pop(i)
                    return

    def getName(self):
        return self.name


class grade():
    """
    The class grade contains 3 elements:
    did - POSITIVE INTEGER representing the id of the discipline the grade is given at
    sid - POSITIVE INTEGER representing the id of the student the grade was given to
    v   - POSITIVE INTEGER representing the value of the grade
    """
    def __init__(self,sid,did,v):
        self.did=did
        self.sid=sid
        self.v=v

    def changeStID(self,id):
        """
        Changes the value of the id representing the stundent that has this grade

        Input id - the new id that the student has
        """
        self.sid=id

    def changeDisID(self,id):
        """
        Changes the value of the id representing the discipline that this grade is assigned at

        Input id - the new id that the discipline has
        """
        self.did=id

class discipline():
    """
    The class contains 2 elements
    name - a STRING representing the name of a discipline
    id - a POSITIVE INTEGER representing the id of a discipline
    """
    def __init__(self,n,id):
        self.name=n
        self.id=id
    def changeName(self,new):
        """
        Modifies the value of the NAME element of SELF
        Input new - STRING representing the new name that the discipline will have
        """
        self.name=new

    def changeID(self,new):
        """
        Modifies the value of the ID element of SELF
        Input new - POSITIVE INTEGER representing the new id that the discipline will have
        """
        self.id=new