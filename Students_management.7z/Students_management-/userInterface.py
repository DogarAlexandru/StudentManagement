from repository import *
from domain import *
from controler import *

class userInterface():
    def __init__(self,stud,disc,grade,unreL):
        self.con=controler(stud, disc, grade,unreL)
    def startUI(self):
        self.mainMenu()

    def readInput(self):
        """
        Reads the input from the user and returns it as a STRING

        Output : s - STRING representing user input
        """
        s=input()
        return s

    def isName(self,s):
        """
        Checks if the STRING inputed represents the name of a person,discipline etc.
        This means that the STRING cannot contain anytghing other than lowercase or uppercase letters
        and spaces

        The fucntion returns FALSE if it finds anything else other than lowercase, uppercase letters
        or spaces or the string is NULL and return TRUE otherwise

        Input: s - STRING to be checked
        Output: TRUE or FALSE by case
        """
        if len(s)==0:
            return False
        a = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM  "
        for i in range(len(s)):
            if a.find(s[i])==-1:
                return False
        return True

    def isNumber(self,s):
        """
        Checks if the STRING inputed represents a number
        This means that the STRING cannot contain anytghing other than digits 0 trough 9

        The fucntion returns FALSE if it finds anything else other than digits 0 trough 9
        or the string is NULL and return TRUE otherwise

        Input: s - STRING to be checked
        Output: TRUE or FALSE by case
        """
        if len(s)==0:
            return False
        for i in range(len(s)):
            if "0123456789".find(s[i]) == -1:
                return False
        return True




    def mainMenu(self):
        """
        The interface for the main menu
        """
        self.printMainMenu()
        s=self.readMyMenuInput()
        self.mainMenuEexecutor(s)

    def printMainMenu(self):
        """
        Prints the main menu of the application
        """
        m = ""
        m = m + "Press 1 to manage students \n"
        m = m + "Press 2 to manage disciplines \n"
        m = m + "Press 3 to grade a student \n"
        m = m + "Press 4 to view all grades \n"
        m = m + "Press 5 to search for a student or discipline \n"
        m = m + "Press 6 to view a statistic \n"
        m = m + "Press 7 to undo the last operation  \n"
        m = m + "Press 8 to redo the last undo executed \n"
        m = m + "Press 9 to exit \n"

        print(m)

    def mainMenuEexecutor(self,s):
        """
        Decides  wich action to take and executes it bassed on wich comand is given trought parameter s

        Input s - STRING representing wich comand the user wants to execute
        """
        if s=="1":
            self.manageStudentsMenu()
        elif s=="2":
            self.manageDisciplinesMenu()
        elif s=="3":
            self.gradeStudentUI()
            self.mainMenu()
        elif s=="4":
            print(self.con.printableGrades())
            s = self.readMyMenuInput()
            self.mainMenuEexecutor(s)
        elif s=="5":
            self.searchMenu()
        elif s=="6":
            self.statisticsMenu()
        elif s=="7":
            self.con.undoLastOperation()
            self.mainMenu()
        elif s=="8":
            self.con.redoLastOperation()
            self.mainMenu()
        elif s=="c":
            self.con.clearData()
            self.mainMenu()

    def mainMenuInputCheck(self,s):
        """
        Verifies if a STRING is the numbers 1 trough 9 returning true if
        the string is these numbers or false if it isn't

        Input s- STRING to be verified
        Output : TRUE of FALSE by case
        """
        if s!="1" and s!="2" and s!="3" and s!="4" and s!="5" and s!="6" and s!="7" and s!="8" and s!="9" and s!="c":
            return False
        return True

    def readMyMenuInput(self):
        """
        Reads commands for my menu until it gets a valid command(positive integer
        between 1 and 9) and returns it

        Output: s - STRING representing the valid command
        """
        print("Type here :) ", end="")
        s = self.readInput()
        while self.mainMenuInputCheck(s) == False:
            print("Invalid command")
            print("Type here :) ", end="")
            s = self.readInput()
        return s








    def manageStudentsMenu(self):
        """
        The interface for the menu of managing student information
        """
        self.printManageStudentsMenu()
        s=""
        while s!="8":
            print("Type here :) ",end="")
            s = self.readInput()
            while self.manageStudentsMenuInputCheck(s)==False:
                print("Invalid command")
                print("Type here :) ", end="")
                s = self.readInput()
            self.manageStudentsMenuExecutor(s)
        self.mainMenu()

    def printManageStudentsMenu(self):
        """
        Prints the student management menu
        """
        m = ""
        m = m + "Press 1 to add a student \n"
        m = m + "Press 2 to remove a student \n"
        m = m + "Press 3 to change a students name \n"
        m = m + "Press 4 to change a students id \n"
        m = m + "Press 5 to enroll a student at a certain discipline \n"
        m = m + "Press 6 to remove a student from a discipline \n"
        m = m + "Press 7 to list al students \n"
        m = m + "Press 8 to return to main menu \n"

        print(m)

    def manageStudentsMenuExecutor(self,s):
        """
        Decides  wich action to take and executes it bassed on wich comand is given trought parameter s

        Input s - STRING representing wich comand the user wants to execute
        """
        if s=="1":
            self.addStudentUI()
        elif s=="2":
            self.removeStudentUI()
        elif s=="3":
            self.changeStudentNameUI()
        elif s=="4":
            self.changeStudentIDUI()
        elif s=="5":
            self.enrollStudentUI()
        elif s=="6":
            self.removeStudentFromDisciplineUI()
        elif s=="7":
            print(self.con.s)

    def addStudentUI(self):
        """
        Gthers the necesary information for adding a studnent to the student list ,and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses the addStudent COMAND from the CONTROLER
        """
        name=input("Type the students name:")
        while self.isName(name)==False:
            print("Thats not the name of a person")
            name = input("Type the students name:")
        id=input("Type the students id:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Type the students id:")
        id=int(id)
        print(self.con.addStudent(name,id))

    def removeStudentUI(self):
        """
        Gthers the necesary information for removing a student from the student list and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses the removeStudent COMAND from the CONTROLER
        """
        id=input("Type the id of the student you want to remove:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id =input("Type the id of the student you want to remove:")
        id=int(id)
        print(self.con.removeStudent(id))

    def changeStudentNameUI(self):
        """
        Gthers the necesary information for changing a students name and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses
        the changeStudnentName COMAND from the CONTROLER
        """
        id=input("Enter the id of the student whose name you want changed:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Enter the id of the student whose name you want changed:")
        id=int(id)
        name=input("Enter the new name:")
        while self.isName(name)==False:
            print("Thats not the name of a person")
            name = input("Enter the new name:")
        print( self.con.changeStudentName(id,name))

    def changeStudentIDUI(self):
        """
        Gthers the necesary information for changing a students id and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses
        the changeStudnentID COMAND from the CONTROLER
        """
        oldid=input("Type the id of the student whose id you want to change:")
        while self.isNumber(oldid)==False:
            print("Thats not a number")
            oldid = input("Type the id of the student whose id you want to change:")
        newid=input("Type the new id:")
        while self.isNumber(newid)==False:
            print("Thats not a number")
            newid = input("Type the new id:")
        oldid=int(oldid)
        newid=int(newid)
        print(self.con.changeStudentID(oldid,newid))

    def enrollStudentUI(self):
        """
        Gthers the necesary information for enrolling a student to a discipline and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses
        the enrollStudent COMAND from the CONTROLER
        """
        id=input("Type the id of the student you want to enroll:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Type the id of the student you want to enroll:")
        di=input("Type the id of the discipline you want the student to be enrolled to:")
        while self.isNumber(di)==False:
            print("Thats not a number")
            di = input("Type the id of the discipline you want the student to be enrolled to:")
        id=int(id)
        di=int(di)
        print(self.con.enrollStudent(id,di))

    def removeStudentFromDisciplineUI(self):
        """
        Gthers the necesary information for removing a student from a discipline and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses
        the removeStudentFromDiscipline COMAND from the CONTROLER
        """
        id=input("Type the id of the student you want to remove from the discipline:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Type the id of the student you want to remove from the discipline:")
        di=input("Type the id of the discipline you want the student to be removed from:")
        while self.isNumber(di)==False:
            print("Thats not a number")
            di = input("Type the id of the discipline you want the student to be removed from:")
        id=int(id)
        di=int(di)
        print(self.con.removeStudentFromDiscipline(id,di))

    def manageStudentsMenuInputCheck(self,s):
        """
        Verifies if a STRING is the numbers 1 trough 8 returning true if
        the string is these numbers or false if it isn't

        Input s- STRING to be verified
        Output : TRUE of FALSE by case
        """
        if s != "1" and s != "2" and s != "3" and s != "4" and s != "5" and s != "6" and s != "7" and s != "8":
            return False
        return True








    def manageDisciplinesMenu(self):
        """
        The interface for managing discipline information
        """
        self.printManageDisciplinesMenu()
        s=""
        while s!="6":
            print("Type here :) ",end="")
            s = self.readInput()
            while self.manageDisciplinesMenuInputCheck(s)==False:
                print("Invalid command")
                print("Type here :) ", end="")
                s = self.readInput()
            self.manageDisciplinesMenuExecutor(s)
        self.mainMenu()

    def printManageDisciplinesMenu(self):
        """
        Prints the student management menu
        """
        m = ""
        m = m + "Press 1 to add a discipline \n"
        m = m + "Press 2 to remove a discipline \n"
        m = m + "Press 3 to change a discipline's name \n"
        m = m + "Press 4 to change a discipline's id \n"
        m = m + "Press 5 to list al disciplines \n"
        m = m + "Press 6 to return to main menu \n"

        print(m)

    def manageDisciplinesMenuExecutor(self,s):
        """
        Decides  wich action to take and executes it bassed on wich comand is given trought parameter s

        Input s - STRING representing wich comand the user wants to execute
        """
        if s=="1":
            self.addDisciplineUI()
        elif s=="2":
            self.removeDisciplineUI()
        elif s=="3":
            self.changeDisciplineNameUI()
        elif s=="4":
            self.changeDisciplineIDUI()
        elif s=="5":
            print(self.con.d)

    def addDisciplineUI(self):
        """
        Gthers the necesary information for adding a discipline to the discipline list ,and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses the addDiscipline COMAND from the CONTROLER
        """
        name=input("Type the discipline's name:")
        while self.isName(name)==False:
            print("Thats not the name of a discipline")
            name = input("Type the discipline's name:")
        id=input("Type the discipline's id:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Type the discipline's id:")
        id=int(id)
        print(self.con.addDiscipline(name,id))

    def removeDisciplineUI(self):
        """
        Gthers the necesary information for removing a discipline from the discipline  list and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses the removeDiscipline COMAND from the CONTROLER
        """
        id=input("Type the id of the discipline  you want to remove:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Type the id of the discipline  you want to remove:")
        id=int(id)
        print(self.con.removeDiscipline(id))

    def changeDisciplineNameUI(self):
        """
        Gthers the necesary information for changing a discipline 's name and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses
        the changeDisciplineName COMAND from the CONTROLER
        """
        id=input("Enter the id of the discipline  whose name you want changed:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Enter the id of the discipline  whose name you want changed:")
        id=int(id)
        name=input("Enter the new name:")
        while self.isName(name)==False:
            print("Thats not the name of a discipline")
            name = input("Enter the new name:")
        print(self.con.changeDisciplineName(id,name))

    def changeDisciplineIDUI(self):
        """
        Gthers the necesary information for changing a discipline 's id and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses
        the changeDisciplineID COMAND from the CONTROLER
        """
        oldid=input("Type the id of the discipline  whose id you want to change:")
        while self.isNumber(oldid)==False:
            print("Thats not a number")
            oldid = input("Type the id of the discipline  whose id you want to change:")
        newid=input("Type the new id:")
        while self.isNumber(newid) == False:
            print("Thats not a number")
            newid = input("Type the new id:")
        oldid=int(oldid)
        newid=int(newid)
        print(self.con.changeDisciplineID(oldid,newid))

    def manageDisciplinesMenuInputCheck(self,s):
        """
        Verifies if a STRING is the numbers 1 trough 6 returning true if
        the string is these numbers or false if it isn't

        Input s- STRING to be verified
        Output : TRUE of FALSE by case
        """
        if s != "1" and s != "2" and s != "3" and s != "4" and s != "5" and s != "6":
            return False
        return True






    def gradeStudentUI(self):
        """
        Gathers the necesary infromation for adding a grade to the grade list and verifies if the information
        is adequate
        Afetr the information got verified the program acceses the command gradeStudent from the
        CONTROLER
        """
        stid=input("Type the id of the student that's getting graded:")
        while self.isNumber(stid)==False:
            print("Thats not a number")
            stid = input("Type the id of the student that's getting graded:")
        dsid=input("Type the id of the discipline the student is graded at:")
        while self.isNumber(dsid) == False:
            print("Thats not a number")
            dsid = input("Type the id of the discipline the student is graded at:")
        v=input("Type the value of the grade:")
        while self.isNumber(v) == False:
            print("Thats not a number")
            v = input("Type the value of the grade:")

        stid=int(stid)
        dsid=int(dsid)
        v=int(v)
        print(self.con.addGrade(stid,dsid,v))







    def searchMenu(self):
        """
        The interface for searching students or disciplines
        """
        self.printSearchMenu()
        s=""
        while s!="5":
            print("Type here :) ", end="")
            s = self.readInput()
            while self.searchMenuInputCheck(s) == False:
                print("Invalid command")
                print("Type here :) ", end="")
                s = self.readInput()
            self.searchMenuEexecutor(s)
        self.mainMenu()

    def printSearchMenu(self):
        """
        Prints the menu for searching students or disciplines
        """
        m = ""
        m = m + "Press 1 to search for  a student based on id \n"
        m = m + "Press 2 to search for  a student based on name \n"
        m = m + "Press 3 to search for  a discipline based on id \n"
        m = m + "Press 4 to search for  a discipline based on name \n"
        m = m + "Press 5 to return to main menu \n"

        print(m)

    def searchMenuEexecutor(self,s):
        """
        Decides  wich action to take and executes it bassed on wich comand is given trought parameter s

        Input s - STRING representing wich comand the user wants to execute
        """
        if s=="1":
            self.searchStudentByIDUI()
        elif s=="2":
            self.searchStudentByNameUI()
        elif s=="3":
            self.searchDisciplineByIDUI()
        elif s=="4":
            self.searchDisciplineByNameUI()
        elif s=="5":
            self.mainMenu()

    def searchStudentByIDUI(self):
        """
        Gthers the necesary information for searching for a student by id and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses the searchStudentByID COMAND from the CONTROLER
        """
        id=input("Type the id by wich you want to search:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Type the id by wich you want to search:")
        id=int(id)
        print(self.con.searchStudentByID(id))

    def searchStudentByNameUI (self):
        """dx
        Gthers the necesary information for searching for a student by name and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses the searchStudentByName COMAND from the CONTROLER
        """
        name=input("Type the students name you want to search by:")
        while self.isName(name)==False:
            print("Thats not the name of a person")
            name = input("Type the students name you want to search by:")
        print(self.con.searchStudentsByName(name))

    def searchDisciplineByIDUI(self):
        """
        Gthers the necesary information for searching for a discipline by id and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses the searchDisciplineByID COMAND from the CONTROLER
        """
        id=input("Type the id by wich you want to search:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Type the id by wich you want to search:")
        id=int(id)
        print(self.con.searchDisciplineByID(id))

    def searchDisciplineByNameUI(self):
        """
        Gthers the necesary information for searching for a student by name and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses the searchStudentByName COMAND from the CONTROLER
        """
        name=input("Type the disciplines name you want to search by:")
        while self.isName(name)==False:
            print("Thats not the name of a person")
            name = input("Type the disciplines name you want to search by:")
        print(self.con.searchDisciplineByName(name))

    def searchMenuInputCheck(self,s):
        """
        Verifies if a STRING is the numbers 1 trough 5 returning true if
        the string is these numbers or false if it isn't

        Input s- STRING to be verified
        Output : TRUE of FALSE by case
        """
        if s != "1" and s != "2" and s != "3" and s != "4" and s != "5":
            return False
        return True








    def statisticsMenu(self):
        """
        The interface for requesting statistics about the school
        """
        self.printStatisticsMenu()
        s=""
        while s!="5":
            print("Type here :) ", end="")
            s = self.readInput()
            while self.statisticsMenuInputCheck(s) == False:
                print("Invalid command")
                print("Type here :) ", end="")
                s = self.readInput()
            self.statisticsMenuEexecutor(s)
        self.mainMenu()

    def printStatisticsMenu(self):
        """
        Prints the menu for searching students or disciplines
        """
        m = ""
        m = m + "Press 1 to show all students enrolled at a given discipline \n"
        m = m + "Press 2 to show all students failing at one or more disciplines  \n"
        m = m + "Press 3 to show students with the best school situation \n"
        m = m + "Press 4 to show all disciplines at which there is at least one grade \n"
        m = m + "Press 5 to return to main menu \n"

        print(m)

    def statisticsMenuEexecutor(self,s):
        """
        Decides  wich action to take and executes it bassed on wich comand is given trought parameter s

        Input s - STRING representing wich comand the user wants to execute
        """
        if s=="1":
            self.studentsEnrolledAtDiciplineUI()
        elif s=="2":
            print(self.con.studentsFailingAtDicipline())
        elif s=="3":
            print(self.con.bestStudents())
        elif s=="4":
            print(self.con.disciplinesWithGrades())
        elif s=="5":
            self.mainMenu()

    def studentsEnrolledAtDiciplineUI(self):
        """
        Gthers the necesary information for listing students enrolled at a given discipline ,and
        verifies that the information is adequate
        After it got the data and verified it , the program acceses the studentsEnrolledAtDicipline COMAND from the CONTROLER
        """
        id=input("Type the discipline's ID:")
        while self.isNumber(id)==False:
            print("Thats not a number")
            id = input("Type the discipline's ID:")
        id=int(id)
        order=input("Type 1 to sort the listing alphabeticaly, or type 2 to sort the listing by average grade:")
        while(order!="1" and order!="2"):
            print("Invalid input")
            order = input("Type 1 to sort the listing alphabeticaly, or type 2 to sort the listing by average grade:")
        order=int(order)
        print(self.con.studentsEnroledAtDiscipline(id,order))

    def statisticsMenuInputCheck(self,s):
        """
        Verifies if a STRING is the numbers 1 trough 5 returning true if
        the string is these numbers or false if it isn't

        Input s- STRING to be verified
        Output : TRUE of FALSE by case
        """
        if s != "1" and s != "2" and s != "3" and s != "4" and s != "5":
            return False
        return True