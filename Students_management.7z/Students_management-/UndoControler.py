
class undoRedoHistory():
    def __init__(self):
        self.history=[]
        self.index=-1

    def addOperations(self,operations):
        self.deleteRedoHistory()
        self.history.append(operations)
        self.index=self.index+1

    def undoLast(self):
        if self.index>=0:
            self.history[self.index].undoAll()
            self.index = self.index - 1
            print("undo succesful")

    def redoLast(self):
        if self.index<len(self.history)-1:
            self.index=self.index+1
            self.history[self.index].redoAll()
            print("redo succesful")

    def deleteRedoHistory(self):
        i=self.index
        ma=len(self.history)
        while i<ma-1:
            self.history.pop(self.index+1)
            i=i+1
    def clearData(self):
        self.history=[]
        self.index=-1



    def __str__(self):
        t=""
        for i in range(len(self.history)):
            t=t+str(self.history[i])+" "
        return t


class operations():
    """
    Greu de explicat :thinking:
    """
    def __init__(self):
        self.un=[]
        self.re=[]
    def addUndoOperation(self,undo):
        self.un.append(undo)
    def addRedoOperation(self,redo):
        self.re.append(redo)
    def undoAll(self):
        for i in range(len(self.un)):
            self.un[i].call()
    def redoAll(self):
        for i in range(len(self.re)):
            self.re[i].call()




class function():
    """
    Class representing a function and its parameters
    ref - the name the function is refered by
    par - a LIST of parameters that the function requires
    """
    def __init__(self,reference,*parameters):
        self.ref=reference
        self.par=parameters

    def call(self):
        """
        Calls the function with the parameters given
        """
        self.ref(*self.par)


"""h=undoRedoHistory()
h.addOperation("0")
h.addOperation("1")
h.addOperation("2")
h.addOperation("3")
h.addOperation("4")
h.addOperation("5")
print(h.index)
print(h)
h.undoLast()
h.undoLast()
h.undoLast()
h.undoLast()
h.undoLast()
h.undoLast()
h.undoLast()
h.undoLast()
h.undoLast()
h.undoLast()
h.undoLast()
h.undoLast()

print(h.index)
print(h)
h.redoLast()
print(h.index)
print(h)
h.undoLast()
h.undoLast()
h.redoLast()
h.redoLast()
h.redoLast()
h.redoLast()
h.redoLast()
h.redoLast()
h.redoLast()
h.redoLast()
h.redoLast()
h.redoLast()
h.redoLast()

h.addOperation("7")
print(h.index)
print(h)
"""