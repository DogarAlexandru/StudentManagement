
def sum(sol,lis):
    sum=0
    for i in range(len(sol)):
        sum=sum+lis[sol[i]]
    return sum
def check(sol):
    for i in range(len(sol)-1):
        if sol[i]>=sol[i+1]:
            return False
    return True
def back(k,lis,s,sol,ok):
    while len(sol)<=k:
        sol.append(0)
    for i in range(len(lis)):
        while len(sol) > k + 1:
            sol.pop()
        sol[k]=i
        if check(sol)==True:
            if sum(sol,lis) == s:
                pri=[]
                for i in range(len(sol)):
                    pri.append(lis[sol[i]])
                print(pri)
                ok[0]=1
            if sum(sol,lis) <s:
                back(k + 1, lis, s, sol,ok)



lis=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,1]
s=8
sol=[]
ok=[0]
back(0,lis,s,sol,ok)
if ok[0]==0:
    print("No payment modality exists")