lis = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 1]
s = 124
sol = []
ok = [0]
k=0
con=-1
sol.append(0)
while len(sol)!=0:
    con=con+1
    while con<len(lis):
        sol[len(sol)-1]=lis[con]
        con=con+1
        if len(sol)<=4:
            if len(sol)==3:
                print(sol)
            else:
                sol.append(0)
    sol.pop()


