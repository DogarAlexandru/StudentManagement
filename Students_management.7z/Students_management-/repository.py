class studentList():
    """
    The class represents a list of students
    Elements of the class:
    li - LIST of entities of the class STUDENT
    """
    def __init__(self):
        self.li=iterable()
    def addStudent(self,st):
        """
        Adds a student to the student list
        Adds an enetity of the class STUDENT to the LIST  of STDUENT class entities li

        Input st - entity of class STUDENT
        """
        self.li[len(self.li)]=st

    def removeStudent(self,id):
        """
        Removes a student from the list of students
        Removes THE FIRST APPARITION of the enetity of class STUDENT from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the student you want removed
        """
        for i in range(len(self.li)):
            if self.li[i].id==id:
                del self.li[i]
                return

    def isIDinList(self,id):
        """
        Verifies if an id of a student is already in te studnent list
        Verifies if any of the id's of the elements of class STUDENT from the LIST li
        is equal to the POSITIVE INTEGER given trough id ,returning TRUE if any of them
        is equa to id and FALSE if none are equal to the integer given trouh id

        Input id - POSITIVE INTEGER reprsenting the id you want to check if it's in the lsit
        """
        for i in range(len(self.li)):
            if self.li[i].id==id:
                return True
        return False

    def getPositionByID(self,id):
        """
        Returns the postion in the list of entities of class student of the entity of class
        student with a given id( trough parameter id).If the id is not in the lsit it reurns -1

        Input id - POSITIVE INTEGER representing the id you want to look for
        Output  - the position of the student with the given id in the student list ,or -1 if
                   the studnet isn't in the list
        """
        for i in range(len(self.li)):
            if self.li[i].id==id:
                return i
        return -1

    def __str__(self):
        """
        Prints all the sudents in the list
        """
        t=""
        for i in range(len(self.li)):
            t=t+(str(self.li[i].id)+" "+self.li[i].name+"\n")
        return t

class disciplineList():
    """
    The class represents a list of disciplines
    Elements of the class:
    li - LIST of entities of the class DISCIPLNE
    """
    def __init__(self):
        self.li=iterable()

    def addDiscipline(self,di):
        """
        Adds a discipline to the discipline list
        Adds an entity of class DISCIPLINE to the LIST of entities of class DISCIPLINE li

        Input di - entity of class DISCIPLINE
        """
        self.li[len(self.li)] = di

    def removeDiscipline(self,id):
        """
        Removes a discipline from the discipline list
        Removes THE FIRST APPARITION of the enetity of class DISCIPLINE from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the disicpline you want removed
        """
        for i in range(len(self.li)):
            if self.li[i].id==id:
                del self.li[i]
                return

    def isIDinList(self,id):
        """
        Verifies if an id of a discipline is already in te discipline list
        Verifies if any of the id's of the elements of class DISCIPLINE from the LIST li
        is equal to the POSITIVE INTEGER given trough id ,returning TRUE if any of them
        is equa to id and FALSE if none are equal to the integer given trouh id

        Input id - POSITIVE INTEGER reprsenting the id you want to check if it's in the lsit
        """
        for i in range(len(self.li)):
            if self.li[i].id == id:
                return True
        return False

    def getPositionByID(self,id):
        """
        Returns the postion in the list of entities of class student of the entity of class
        student with a given id( trough parameter id).If the id is not in the lsit it reurns -1

        Input id - POSITIVE INTEGER representing the id you want to look for
        Output  - the position of the student with the given id in the student list ,or -1 if
                   the studnet isn't in the list
        """
        for i in range(len(self.li)):
            if self.li[i].id==id:
                return i
        return -1

    def __str__(self):
        """
        Prints all the disciplines in the list
        """
        t=""
        for i in range(len(self.li)):
            t=t+(str(self.li[i].id)+" "+self.li[i].name+"\n")
        return t

class gradeList():
    """
    Represents the lsit of grades given at the school
    Contains 1 element:
    li - LIST of entities of class GRADE
    """
    def __init__(self):
        self.li=iterable()

    def addGrade(self,g):
        """
        Adds a grade to the grade list
        Adds an entity of the class GRADE to the LIST of entities of class GRADE

        Input g - entity of class GRADE
        """
        self.li[len(self.li)] = g

    def removeGradeStd(self,id):
        """
        Removes the grades of the students with a given id from the grade list
        Removes ALL THE  APPARITIONS of the enetity of class GRADE from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the student who's grade you want removed
        """
        ok=1
        while ok==1:
            ok=0
            for i in range(len(self.li)):
                if self.li[i].sid == id:
                    del self.li[i]
                    ok = 1
                    break

    def removeGradeDis(self,id):
        """
        Removes the grades of the discipline with a given id from the grade list
        Removes ALL THE  APPARITIONS of the enetity of class GRADE from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the discipline who's grade you want removed
        """
        ok = 1
        while ok == 1:
            ok = 0
            for i in range(len(self.li)):
                if self.li[i].did == id:
                    del self.li[i]
                    ok = 1
                    break

    def removeLastGrade(self):
        """
        Removes the element last added to the LIST of entities of class GRADE
        """
        self.li.pop()


class iterable():
    def __init__(self):
        self.li=[]
        self.index=0

    def __iter__(self):
        return iter(self.li)

    def __len__(self):
        return len(self.li)

    def __getitem__(self, item):
        if len(self.li)>item and item>=0:
            return self.li[item]
        else:
            raise IndexError

    def __setitem__(self, key, value):
        if len(self.li)>key and key>=0:
            self.li[key]=value
        elif key>=0:
            self.li.append(value)

    def __delitem__(self, key):
        if len(self.li)>key and key>=0:
            del self.li[key]
        else:
            raise IndexError

    def __next__(self):
        if self.index>= len(self.li):
            raise StopIteration
        else:
            self.index=self.index+1
            return self.li[self.index-1]

    def pop(self):
        del self.li[len(self.li)-1]

def sort(li,func):
    """
    gnomesort
    Input:li - LIST that will be sorted
          func -FUNCTION with 2 parameters that returns TRUE or FALSE
    """
    pos=0
    while pos<len(li):
        if pos==0 or func(li[pos],li[pos-1])==False:
            pos=pos+1
        else:
            li[pos],li[pos-1]=li[pos-1],li[pos]
            pos=pos-1

def filter(li,func):
    """
    Input:li - LIST that will be filtered
          func -FUNCTION with 2 parameters that returns TRUE or FALSE
    """
    ok=1
    while ok==1:
        ok=0
        for i in range(len(li)):
            if func(li[i]) == False:
                del li[i]
                ok=1
                break