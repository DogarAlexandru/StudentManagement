from repository import *
from UndoControler import *
from domain import *
class controler():
    def __init__(self,stud,disc,grade,unreL):
        self.s=stud
        self.d=disc
        self.g=grade
        self.u=unreL


    def insensitivize(self,st):
        """
        Changes all the characters from STRING st into lowercase characters

        Input: st - STRING containing LETTERS of the english alphabet
        Output: st - STRING representing a copy of the string st but with all characters turned lowercase
        """
        return st.lower()

    def addStudent(self,name,id):
        if self.s.isIDinList(id)==False:
            stud = student(name, id)
            self.s.addStudent(stud)
            undo = function(self.removeStudent2, id)
            redo = function(self.addStudent2, name, id)
            oper = operations()
            oper.addUndoOperation(undo)
            oper.addRedoOperation(redo)
            self.u.addOperations(oper)
            t="Student succesfully added"
            return t
        else:
            t="Adding was unsuccesfull, student id is already in list"
            return t

    def addStudent2(self,name,id):
        if self.s.isIDinList(id)==False:
            stud = student(name, id)
            self.s.addStudent(stud)
            t="Student succesfully added"

    def addDiscipline(self,name,id):
        if self.d.isIDinList(id)==False:
            disc = discipline(name, id)
            self.d.addDiscipline(disc)
            oper=operations()
            undo=function(self.removeDiscipline2,id)
            oper.addUndoOperation(undo)
            redo=function(self.addDiscipline2,name,id)
            oper.addRedoOperation(redo)
            self.u.addOperations(oper)
            t = "Discipline succesfully added"
            return t
        else:
            t="Adding was unsuccesfull , discipline id is already in list"
            return t

    def addDiscipline2(self,name,id):
        if self.d.isIDinList(id)==False:
            disc = discipline(name, id)
            self.d.addDiscipline(disc)

    def addGrade(self,sid,did,v):
        if self.d.isIDinList(did)==True:
             if self.s.isIDinList(sid)==True:
                    p=self.s.getPositionByID(sid)
                    if self.s.li[p].isEnrolled(did)==True:
                        gr = grade(sid, did, v)
                        self.g.addGrade(gr)
                        oper=operations()
                        undo1=function(self.popGrade)
                        oper.addUndoOperation(undo1)
                        redo1=function(self.addGrade2,sid,did,v)
                        oper.addRedoOperation(redo1)
                        self.u.addOperations(oper)
                        t = "Grade added succesfully"
                        return t
                    else:
                        t="Adding was unsuccesful,student is not enrolled at discipline \n"
                        return t
             else:
                 t="Adding was unsuccesfull,student is not attending the school \n"
                 return t
        else:
            t = "Adding was unsuccesfull,discipline id is not in list \n"
            return t

    def addGrade2(self,sid,did,v):
        if self.d.isIDinList(did)==True:
             if self.s.isIDinList(sid)==True:
                    p=self.s.getPositionByID(sid)
                    if self.s.li[p].isEnrolled(did)==True:
                        gr = grade(sid, did, v)
                        self.g.addGrade(gr)

    def popGrade(self):
        """
        Removes the element last added to the LIST of entities of class GRADE
        This function is not accesible for the user, it is made for the undo functionality
        """
        self.g.removeLastGrade()

    def enrollStudent(self,sid,did):
        if self.d.isIDinList(did)==True:
            if self.s.isIDinList(sid)==True:
                p = self.s.getPositionByID(sid)
                if self.s.li[p].isEnrolled(did) == False:
                    self.s.li[p].addDiscipline(did)
                    oper=operations()
                    undo1=function(self.unEnrollStudet,sid,did)
                    oper.addUndoOperation(undo1)
                    redo1=function(self.enrollStudent2,sid,did)
                    oper.addRedoOperation(redo1)
                    self.u.addOperations(oper)
                    t="Student succesfully enrolled"
                else:
                    t="Enrolling unsuccesfull,student is already enrolled at discipline "
            else:
                t = "Enrolling unsuccesfull,student id is not in list "
        else:
            t = "Enrolling unsuccesfull,disciline id is not in the list "
        return t

    def enrollStudent2(self,sid,did):
        if self.d.isIDinList(did)==True:
            if self.s.isIDinList(sid)==True:
                p = self.s.getPositionByID(sid)
                if self.s.li[p].isEnrolled(did) == False:
                    self.s.li[p].addDiscipline(did)

    def unEnrollStudet(self,sid,did):
        """
        Removes the discipline with id DID from the discipline list of student with id SID
        This function is not accesible to users trough ui , it is made for the undo functionality,
        therefore it dosen't check the validity of it's parameters
        """
        p = self.s.getPositionByID(sid)
        self.s.li[p].removeDiscipline(did)

    def removeStudent(self,sid):
        if self.s.isIDinList(sid) == True:
            p=self.s.getPositionByID(sid)
            name=self.s.li[p].name
            oper=operations()
            undo=function(self.addStudent2,name,sid)
            oper.addUndoOperation(undo)
            for i in range(len(self.s.li[p].dl)):
                undo=function(self.enrollStudent2,sid,self.s.li[p].dl[i])
                oper.addUndoOperation(undo)
            for i in range(len(self.g.li)):
                if self.g.li[i].sid==sid:
                    undo=function(self.addGrade2,sid,self.g.li[i].did,self.g.li[i].v)
                    oper.addUndoOperation(undo)
            redo=function(self.removeStudent2,sid)
            oper.addRedoOperation(redo)
            self.u.addOperations(oper)
            self.s.removeStudent(sid)
            self.g.removeGradeStd(sid)
            t="Student removed succesfully"
        else:
            t="Removing unsuccesfull,student id is not in the list"
        return t

    def removeStudent2(self,sid):
        if self.s.isIDinList(sid) == True:
            self.s.removeStudent(sid)
            self.g.removeGradeStd(sid)

    def removeDiscipline(self,did):
        if self.d.isIDinList(did) == True:
            oper=operations()
            p=self.d.getPositionByID(did)
            undo=function(self.addDiscipline2,self.d.li[p].name,did)
            oper.addUndoOperation(undo)
            for i in range(len(self.g.li)):
                if self.g.li[i].did==did:
                    undo=function(self.addGrade2,self.g.li[i].sid,did,self.g.li[i].v)
                    oper.addUndoOperation(undo)
            redo=function(self.removeDiscipline2,did)
            oper.addRedoOperation(redo)
            self.u.addOperations(oper)
            self.d.removeDiscipline(did)
            self.g.removeGradeDis(did)
            t="Discipline removed succesfully"
        else:
            t="Removal unsuccesful,discipline id is not in list"
        return t

    def removeDiscipline2(self,did):
        if self.d.isIDinList(did) == True:
            self.d.removeDiscipline(did)
            self.g.removeGradeDis(did)

    def removeStudentFromDiscipline(self,sid,did):
        if self.d.isIDinList(did)==True:
          if self.s.isIDinList(sid)==True:
              p = self.s.getPositionByID(sid)
              if self.s.li[p].isEnrolled(did) == True:
                  oper=operations()
                  undo=function(self.enrollStudent2,sid,did)
                  oper.addUndoOperation(undo)
                  redo=function(self.removeStudentFromDiscipline2,sid,did)
                  oper.addRedoOperation(redo)
                  self.u.addOperations(oper)
                  self.s.li[p].removeDiscipline(did)
                  t="Studnt removed from discipline succesfully"
              else:
                  t="Removal unsuccesfull, student is not enrolled at given discipline"
          else:
              t = "Removing unsuccesfull,student id is not in the list"
        else:
            t = "Removal unsuccesful,discipline id is not in list"
        return t

    def removeStudentFromDiscipline2(self,sid,did):
        if self.d.isIDinList(did)==True:
          if self.s.isIDinList(sid)==True:
              p = self.s.getPositionByID(sid)
              if self.s.li[p].isEnrolled(did) == True:
                  self.s.li[p].removeDiscipline(did)

    def changeStudentName(self,sid,name):
        if self.s.isIDinList(sid) == True:
            p = self.s.getPositionByID(sid)
            oper=operations()
            undo=function(self.changeStudentName2,sid,self.s.li[p].name)
            oper.addUndoOperation(undo)
            redo=function(self.changeStudentName2,sid,name)
            oper.addRedoOperation(redo)
            self.u.addOperations(oper)
            self.s.li[p].changeName(name)
            t="Name change succesfull"
        else:
            t="Name change unsuccesfull, student id is not in list"
        return t

    def changeStudentName2(self,sid,name):
        if self.s.isIDinList(sid) == True:
            p = self.s.getPositionByID(sid)
            self.s.li[p].changeName(name)

    def changeStudentID(self,sidd,nid):
        if self.s.isIDinList(sidd) == True:
            if self.s.isIDinList(nid) == False:
                p = self.s.getPositionByID(sidd)
                oper = operations()
                undo = function(self.changeStudentID2, nid, sidd)
                oper.addUndoOperation(undo)
                redo = function(self.changeStudentID2, sidd, nid)
                oper.addRedoOperation(redo)
                self.u.addOperations(oper)
                self.s.li[p].changeID(nid)
                t="Id changed succesfully"
                for i in range(len(self.g.li)):
                    if self.g.li[i].sid==sidd:
                        self.g.li[i].changeStID(nid)
            else:
                t="Id changed unsuccesfuly ,  new id is already in list"
        else:
            t="Id changed unsuccesfully,student id is not in the list"
        return t

    def changeStudentID2(self,sidd,nid):
        if self.s.isIDinList(sidd) == True:
            if self.s.isIDinList(nid) == False:
                p = self.s.getPositionByID(sidd)
                self.s.li[p].changeID(nid)
                t="Id changed succesfully"
                for i in range(len(self.g.li)):
                    if self.g.li[i].sid==sidd:
                        self.g.li[i].changeStID(nid)

    def changeDisciplineName(self,did,name):
        if self.d.isIDinList(did) == True:
            p=self.d.getPositionByID(did)
            oper = operations()
            undo = function(self.changeDisciplineName2, did, self.d.li[p].name)
            oper.addUndoOperation(undo)
            redo = function(self.changeDisciplineName2, did, name)
            oper.addRedoOperation(redo)
            self.u.addOperations(oper)
            self.d.li[p].changeName(name)
            t="Name succesfully changed"
        else:
            t="Name chage unsuccesfull , discipline id is not in list"
        return t

    def changeDisciplineName2(self,did,name):
        if self.d.isIDinList(did) == True:
            p=self.d.getPositionByID(did)
            self.d.li[p].changeName(name)

    def changeDisciplineID(self,did,nid):
        if self.d.isIDinList(did) == True:
            if self.d.isIDinList(nid) == False:
                p = self.d.getPositionByID(did)
                oper = operations()
                undo = function(self.changeDisciplineID2, nid, did)
                oper.addUndoOperation(undo)
                redo = function(self.changeDisciplineID2, did, nid)
                oper.addRedoOperation(redo)
                self.u.addOperations(oper)
                self.d.li[p].changeID(nid)
                t="Id changed succesfully"
                for i in range(len(self.g.li)):
                    if self.g.li[i].did==did:
                        self.g.li[i].changeDisID(nid)
            else:
                t="Id changed unsuccesfully,new id is already in list"
        else:
            t="Id changed unsuccesfully, discipline id is not in list"
        return t

    def changeDisciplineID2(self,did,nid):
        if self.d.isIDinList(did) == True:
            if self.d.isIDinList(nid) == False:
                p = self.d.getPositionByID(did)
                self.d.li[p].changeID(nid)

    def printableGrades(self):
        t=""
        for i in range(len(self.g.li)):
            sid = self.g.li[i].sid
            did = self.g.li[i].did
            ps=self.s.getPositionByID(sid)
            pd=self.d.getPositionByID(did)
            t=t+self.s.li[ps].name+"("+str(sid)+")"+" "+self.d.li[pd].name+"("+str(did)+")"+ "  grade:"+str(self.g.li[i].v)+"\n"
        return t

    def searchStudentByID(self,id):
        t=""
        for i in range(len(self.s.li)):
            original=str(self.s.li[i].id)
            findee=str(id)
            if original.find(findee)!=-1:
                t=t+str(self.s.li[i].id)+" "+self.s.li[i].name+"\n"
        if t=="":
            t=t+"No students found"
        return t

    def searchDisciplineByID(self,id):
        t=""
        for i in range(len(self.d.li)):
            original=str(self.d.li[i].id)
            findee=str(id)
            if original.find(findee)!=-1:
                t=t+str(self.d.li[i].id)+" "+self.d.li[i].name+"\n"
        if t=="":
            t=t+"No disciplines found"
        return t

    def searchStudentsByName(self,name):
        name=self.insensitivize(name)
        t=""
        for i in range(len(self.s.li)):
            original = self.insensitivize(self.s.li[i].name)
            if original.find(name)!=-1:
                t = t + str(self.s.li[i].id) + " " + self.s.li[i].name + "\n"
        if t=="":
            t=t+"No students found"
        return t

    def searchDisciplineByName(self,name):
        name = self.insensitivize(name)
        t = ""
        for i in range(len(self.d.li)):
            original = self.insensitivize(self.d.li[i].name)
            if original.find(name) != -1:
                t = t + str(self.d.li[i].id) + " " + self.d.li[i].name + "\n"
        if t == "":
            t = t + "No diciplines found"
        return t

    def studentsEnroledAtDiscipline(self,did,order):
        lis=[]
        for i in range(len(self.s.li)):
            if self.s.li[i].isEnrolled(did)==True:
                """ sfs = searched for student """
                avg=self.averageStudentGrade(self.s.li[i].id)
                stud=self.s.li[i]
                sfs=statsObj(stud,avg)
                lis.append(sfs)
        if order==1:
            sort(lis,compareNames)
        elif order==2:
            sort(lis,compareAveragesDescend)
        t=""
        for i in range(len(lis)):
            t=t+lis[i].obj.name+"\n"
        if t=="":
            t="No students enrolled at discipline with id "+str(did)
        return t

    def studentsFailingAtDicipline(self):
        lis=[]
        for i in range(len(self.s.li)):
            for j in range(len(self.s.li[i].dl)):
                av=self.averageDiscipineGrade(self.s.li[i].id,self.s.li[i].dl[j])
                if av<5 and av>0:
                    stud=self.s.li[i]
                    sfs = statsObj(stud, av)
                    lis.append(sfs)
                    break
        t = ""
        for i in range(len(lis)):
            t = t + lis[i].obj.name + "\n"
        if t=="":
            t="Students are good for now"
        return t

    def averageDiscipineGrade(self,sid,did):
        """
        Gets the id of a student and the id of a discipline and returns the average grade of
        that student at that discipline
        Input sid - POSITIVE INTEGER representing the id of a student
              did - POSITIVE INTEGER representing the id of discipline
        Output av - POSITIVE INTEGER repersenting the average grade of stdent with
                    id sid at discipline with id did
        """
        av=0
        s=0
        nr=0
        for i in range(len(self.g.li)):
            if self.g.li[i].did==did:
                if self.g.li[i].sid==sid:
                    s=s+self.g.li[i].v
                    nr=nr+1
        if nr==0:
            nr=1
        av=s/nr
        return av

    def bestStudents(self):
        lis=[]
        for i in range(len(self.s.li)):
            if self.averageStudentGrade(self.s.li[i].id)>0:
                avg=self.averageStudentGrade(self.s.li[i].id)
                stud=self.s.li[i]
                sfs=statsObj(stud,avg)
                lis.append(sfs)
        for i in range(len(lis) - 1):
            sort(lis,compareAveragesDescend)
        t = ""
        for i in range(len(lis)):
            t = t + lis[i].obj.name+"  average grade:" +str(lis[i].avg) + "\n"
        if t=="":
            t="Students have no grades"
        return t

    def disciplinesWithGrades(self):
        lis=[]
        for i in range(len(self.d.li)):
            av=self.averageDisciplineTotalGrade(self.d.li[i].id)
            if av>0:
                disc=self.d.li[i]
                sfd=statsObj(disc,av)
                lis.append(sfd)
        for i in range(len(lis) - 1):
            sort(lis, compareAveragesDescend)
        t=""
        for i in range(len(lis)):
            t=t+lis[i].obj.name+" average grade:"+str(lis[i].avg)+"\n"
        if t=="":
            t="No disciplines have grades"
        return t

    def averageStudentGrade(self,sid):
        """
        Gets the id of a student and returns the average grade of
        that student
        Input sid - POSITIVE INTEGER representing the id of a student
        Output av - POSITIVE INTEGER repersenting the average grade of stdent with
                    id sid
        """
        av=0
        s=0
        nr=0
        for i in range(len(self.g.li)):
            if self.g.li[i].sid==sid:
                s=s+self.g.li[i].v
                nr=nr+1
        if nr==0:
            nr=1
        av=s/nr
        return av

    def averageDisciplineTotalGrade(self,did):
        """
         Gets the id of a dicipline and returns the average grade of
         the studets at that disipline
         Input sid - POSITIVE INTEGER representing the id of a disicipline
         Output av - POSITIVE INTEGER repersenting the average grade of a discipline with
                     id did
         """
        av = 0
        s = 0
        nr = 0
        for i in range(len(self.g.li)):
            if self.g.li[i].did == did:
                s = s + self.g.li[i].v
                nr = nr + 1
        if nr == 0:
            nr = 1
        av = s / nr
        return av

    def clearData(self):
        """
        Erases all data from the 3 repositories
        For testing purposes
        """
        while(len(self.s.li)!=0):
            self.s.li.pop()
        while (len(self.d.li) != 0):
            self.d.li.pop()
        while (len(self.g.li) != 0):
            self.g.li.pop()

    def undoLastOperation(self):
        self.u.undoLast()

    def redoLastOperation(self):
        self.u.redoLast()


class statsObj():
    def __init__(self,obj,average):
        self.obj=obj
        self.avg=average

def sort(li,func):
    """
    gnomesort
    Input:li - LIST that will be sorted
          func -FUNCTION with 2 parameters that returns TRUE or FALSE
    """
    pos=0
    while pos<len(li):
        if pos==0 or func(li[pos],li[pos-1])==False:
            pos=pos+1
        else:
            li[pos],li[pos-1]=li[pos-1],li[pos]
            pos=pos-1

def filter(li,func):
    """
    Input:li - LIST that will be filtered
          func -FUNCTION with 2 parameters that returns TRUE or FALSE
    """
    ok=1
    while ok==1:
        ok=0
        for i in range(len(li)):
            if func(li[i]) == False:
                del li[i]
                ok=1
                break

def compareNames(f,s):
    if f.obj.name<s.obj.name:
        return True
    else:
        return False

def compareAveragesAscend(f,s):
    if f.avg<s.avg:
        return True
    else:
        return False

def compareAveragesDescend(f,s):
    if f.avg>s.avg:
        return True
    else:
        return False