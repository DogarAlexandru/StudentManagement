from domain import *
from repository import *
import pickle
class studentListBinary(studentList):
    """
    The class represents a list of students
    Elements of the class:
    li - LIST of entities of the class STUDENT
    """
    def __init__(self,file):
        studentList.__init__(self)
        self.fi=file
        self.loadFromFile()

    def loadFromFile(self):
        try:
            f = open(self.fi, "rb")
        except IOError:
            return
        stList=[]
        try:
            stList=pickle.load(f)
        except EOFError:
            stList=[]
        except IOError:
            return
        for i in range(len(stList)):
            self.addStudent(stList[i])

        f.close()

    def saveToFile(self):
        try:
            f = open(self.fi, "wb")
        except IOError:
            return
        pickle.dump(self.li,f)
        f.close()

    def addStudent(self,st):
        """
        Adds a student to the student list
        Adds an enetity of the class STUDENT to the LIST  of STDUENT class entities li

        Input st - entity of class STUDENT
        """
        studentList.addStudent(self,st)
        self.saveToFile()

    def removeStudent(self,id):
        """
        Removes a student from the list of students
        Removes THE FIRST APPARITION of the enetity of class STUDENT from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the student you want removed
        """
        studentList.removeStudent(self,id)
        self.saveToFile()

class disciplineListBinary(disciplineList):
    """
    The class represents a list of disciplines
    Elements of the class:
    li - LIST of entities of the class DISCIPLNE
    """
    def __init__(self,file):
        disciplineList.__init__(self)
        self.fi=file
        self.loadFromFile()

    def saveToFile(self):
        try:
            f = open(self.fi, "wb")
        except IOError:
            return
        pickle.dump(self.li,f)
        f.close()

    def loadFromFile(self):
        try:
            f = open(self.fi, "rb")
        except IOError:
            return
        diList=[]
        try:
            diList=pickle.load(f)
        except EOFError:
            diList=[]
        except IOError:
            return
        for i in range(len(diList)):
            self.addDiscipline(diList[i])

    def addDiscipline(self,di):
        """
        Adds a discipline to the discipline list
        Adds an entity of class DISCIPLINE to the LIST of entities of class DISCIPLINE li

        Input di - entity of class DISCIPLINE
        """
        disciplineList.addDiscipline(self,di)
        self.saveToFile()

    def removeDiscipline(self,id):
        """
        Removes a discipline from the discipline list
        Removes THE FIRST APPARITION of the enetity of class DISCIPLINE from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the disicpline you want removed
        """
        disciplineList.removeDiscipline(self,id)
        self.saveToFile()

class gradeListBinary(gradeList):
    """
    Represents the lsit of grades given at the school
    Contains 1 element:
    li - LIST of entities of class GRADE
    """
    def __init__(self,file):
        gradeList.__init__(self)
        self.fi=file
        self.loadFromFile()

    def saveToFile(self):
        try:
            f = open(self.fi, "wb")
        except IOError:
            return
        pickle.dump(self.li,f)
        f.close()

    def loadFromFile(self):
        try:
            f = open(self.fi, "rb")
        except IOError:
            return
        grList=[]
        try:
            grList=pickle.load(f)
        except EOFError:
            grList=[]
        except IOError:
            return
        for i in range(len(grList)):
            self.addGrade(grList[i])

    def addGrade(self,g):
        """
        Adds a grade to the grade list
        Adds an entity of the class GRADE to the LIST of entities of class GRADE

        Input g - entity of class GRADE
        """
        gradeList.addGrade(self,g)
        self.saveToFile()

    def removeGradeStd(self,id):
        """
        Removes the grades of the students with a given id from the grade list
        Removes ALL THE  APPARITIONS of the enetity of class GRADE from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the student who's grade you want removed
        """
        gradeList.removeGradeStd(self,id)
        self.saveToFile()

    def removeGradeDis(self,id):
        """
        Removes the grades of the discipline with a given id from the grade list
        Removes ALL THE  APPARITIONS of the enetity of class GRADE from the LIST li that has
        the propriety of having the same id as the INTEGER given trough id

        Input id - POSITIVE INTEGER representing the id of the discipline who's grade you want removed
        """
        gradeList.removeGradeDis(self,id)
        self.saveToFile()

    def removeLastGrade(self):
        """
        Removes the element last added to the LIST of entities of class GRADE
        """
        gradeList.removeLastGrade(self)
        self.saveToFile()